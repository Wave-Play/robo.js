export const config = {
	description: 'Replies with Pong!'
}

export default () => {
	return 'Pong!'
}
