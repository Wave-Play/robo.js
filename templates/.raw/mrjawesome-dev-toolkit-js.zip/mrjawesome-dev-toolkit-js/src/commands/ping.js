export const config = {
	description: 'Pong!'
}

export default (interaction) => {
	interaction.reply('Pong!')
}
